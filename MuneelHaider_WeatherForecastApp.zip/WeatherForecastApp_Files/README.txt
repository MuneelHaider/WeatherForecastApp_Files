Developed by Muneel Haider.

In order to run these files, you are to paste these files into the ASP.NET Project folder you have created.
Replace these files and the webapp should run fine since it is configured to run Index.cshtml as its home page.